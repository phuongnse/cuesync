Subtitles for Show, season 1.
